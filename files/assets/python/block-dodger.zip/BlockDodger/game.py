import pygame
import random
import os

# Initialize Pygame
pygame.init()

# Set fixed window size
WIDTH, HEIGHT = 1600, 950
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Block Dodger")

# Colors
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE = (0, 0, 200)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
GRAY = (100, 100, 100)

# Player settings
player_size = 50
player_speed = 7

# Enemy settings
enemy_size = 50
enemy_speed = 5
enemy_list = []

# Clock and font
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 30)

# High score tracking
data_dir = os.path.expanduser("~/Documents/BlockDodger")
os.makedirs(data_dir, exist_ok=True)
high_score_file = os.path.join(data_dir, "highscore.txt")
high_score = 0
if os.path.exists(high_score_file):
    try:
        with open(high_score_file, "r") as f:
            high_score = int(f.read().strip())
    except:
        high_score = 0

def save_high_score(score):
    global high_score
    if score > high_score:
        high_score = score
        with open(high_score_file, "w") as f:
            f.write(str(score))

# Load and play background music
music_file = "C:/Users/ACER/Desktop/BlockDodger/bg_music.mp3"
if os.path.exists(music_file):
    try:
        pygame.mixer.music.load(music_file)
        pygame.mixer.music.set_volume(1.0)
        pygame.mixer.music.play(-1, 0.0)
    except pygame.error as e:
        print("Error loading music:", e)
else:
    print(f"Music file '{music_file}' not found!")

def is_mouse_over(button_rect):
    mouse_pos = pygame.mouse.get_pos()
    return button_rect.collidepoint(mouse_pos)

def show_menu():
    menu = True
    while menu:
        dt = clock.tick(60)
        win.fill(BLACK)

        title_text = font.render("Block Dodger", True, WHITE)
        win.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))

        high_score_text = font.render(f"High Score: {high_score}", True, WHITE)
        win.blit(high_score_text, (WIDTH // 2 - high_score_text.get_width() // 2, HEIGHT // 2 - 60))

        start_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2, 200, 50)
        quit_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 60, 200, 50)

        start_color = GREEN if is_mouse_over(start_button) else (0, 200, 0)
        quit_color = RED if is_mouse_over(quit_button) else (200, 0, 0)

        pygame.draw.rect(win, start_color, start_button)
        pygame.draw.rect(win, quit_color, quit_button)

        win.blit(font.render("Start Game", True, WHITE), (WIDTH // 2 - 65, HEIGHT // 2 + 10))
        win.blit(font.render("Quit Game", True, WHITE), (WIDTH // 2 - 60, HEIGHT // 2 + 70))

        fps_text = font.render(f"FPS: {clock.get_fps():.1f}", True, WHITE)
        win.blit(fps_text, (WIDTH - fps_text.get_width() - 10, 10))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos):
                    menu = False
                elif quit_button.collidepoint(event.pos):
                    pygame.quit()
                    quit()

def draw_health_bar(health):
    max_width = 300
    height = 25
    x = WIDTH // 2 - max_width // 2
    y = 10
    pygame.draw.rect(win, GRAY, (x, y, max_width, height))
    current_width = max(0, int((health / 100) * max_width))
    pygame.draw.rect(win, GREEN, (x, y, current_width, height))
    health_text = font.render(f"HP: {health}", True, WHITE)
    win.blit(health_text, (x + max_width // 2 - health_text.get_width() // 2, y + 2))

def show_pause_menu():
    while True:
        dt = clock.tick(60)
        win.fill(BLACK)

        pause_text = font.render("Game Paused", True, WHITE)
        resume_text = font.render("Resume", True, WHITE)
        menu_text = font.render("Main Menu", True, WHITE)
        quit_text = font.render("Quit", True, WHITE)

        resume_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2, 200, 50)
        menu_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 60, 200, 50)
        quit_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 120, 200, 50)

        resume_color = GREEN if is_mouse_over(resume_button) else (0, 200, 0)
        menu_color = (0, 150, 255) if is_mouse_over(menu_button) else (0, 100, 200)
        quit_color = RED if is_mouse_over(quit_button) else (200, 0, 0)

        win.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2 - 80))
        pygame.draw.rect(win, resume_color, resume_button)
        pygame.draw.rect(win, menu_color, menu_button)
        pygame.draw.rect(win, quit_color, quit_button)

        win.blit(resume_text, (WIDTH // 2 - resume_text.get_width() // 2, HEIGHT // 2 + 10))
        win.blit(menu_text, (WIDTH // 2 - menu_text.get_width() // 2, HEIGHT // 2 + 70))
        win.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 130))

        fps_text = font.render(f"FPS: {clock.get_fps():.1f}", True, WHITE)
        win.blit(fps_text, (WIDTH - fps_text.get_width() - 10, 10))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
            if event.type == pygame.MOUSEBUTTONDOWN:
                if resume_button.collidepoint(event.pos):
                    return
                elif menu_button.collidepoint(event.pos):
                    return "menu"
                elif quit_button.collidepoint(event.pos):
                    pygame.quit()
                    quit()

def drop_enemies(enemy_list):
    if len(enemy_list) < 10 and random.random() < 0.1:
        x_pos = random.randint(0, WIDTH - enemy_size)
        enemy_list.append([x_pos, 0])

def draw_enemies(enemy_list):
    for enemy in enemy_list:
        pygame.draw.rect(win, RED, (enemy[0], enemy[1], enemy_size, enemy_size))

def update_enemy_positions(enemy_list):
    for enemy in enemy_list:
        enemy[1] += enemy_speed
    enemy_list[:] = [enemy for enemy in enemy_list if enemy[1] < HEIGHT]

def collision(player_pos, enemy_pos):
    px, py = player_pos
    ex, ey = enemy_pos
    return ex < px + player_size and ex + enemy_size > px and ey < py + player_size and ey + enemy_size > py

def detect_collisions(enemy_list, player_pos):
    collided = []
    for enemy in enemy_list:
        if collision(player_pos, enemy):
            collided.append(enemy)
    return collided

def show_game_over(score):
    while True:
        dt = clock.tick(60)
        win.fill(BLACK)

        game_over_text = font.render("Game Over!", True, WHITE)
        score_text = font.render(f"Score: {score}", True, WHITE)
        high_score_text = font.render(f"High Score: {high_score}", True, WHITE)
        restart_text = font.render("Restart", True, WHITE)
        quit_text = font.render("Quit", True, WHITE)

        restart_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 60, 200, 50)
        quit_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 120, 200, 50)

        restart_color = GREEN if is_mouse_over(restart_button) else (0, 200, 0)
        quit_color = RED if is_mouse_over(quit_button) else (200, 0, 0)

        win.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 80))
        win.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 40))
        win.blit(high_score_text, (WIDTH // 2 - high_score_text.get_width() // 2, HEIGHT // 2))

        pygame.draw.rect(win, restart_color, restart_button)
        pygame.draw.rect(win, quit_color, quit_button)

        win.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 70))
        win.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 130))

        fps_text = font.render(f"FPS: {clock.get_fps():.1f}", True, WHITE)
        win.blit(fps_text, (WIDTH - fps_text.get_width() - 10, 10))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if restart_button.collidepoint(event.pos):
                    return True
                elif quit_button.collidepoint(event.pos):
                    pygame.quit()
                    quit()

def main():
    global enemy_list
    show_menu()

    running = True
    score = 0
    health = 100
    player_x = WIDTH // 2 - player_size // 2
    player_y = HEIGHT - player_size - 10
    enemy_list.clear()

    while running:
        dt = clock.tick(60)
        win.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                result = show_pause_menu()
                if result == "menu":
                    return

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < WIDTH - player_size:
            player_x += player_speed

        drop_enemies(enemy_list)
        update_enemy_positions(enemy_list)

        collided_enemies = detect_collisions(enemy_list, (player_x, player_y))
        if collided_enemies:
            for enemy in collided_enemies:
                enemy_list.remove(enemy)
            health -= 33
            if health <= 0:
                final_score = score // 10
                save_high_score(final_score)
                if show_game_over(final_score):
                    return

        draw_enemies(enemy_list)
        pygame.draw.rect(win, BLUE, (player_x, player_y, player_size, player_size))

        score += 1
        win.blit(font.render("Score: " + str(score // 10), True, WHITE), (10, 10))

        draw_health_bar(health)

        fps_text = font.render(f"FPS: {clock.get_fps():.1f}", True, WHITE)
        win.blit(fps_text, (WIDTH - fps_text.get_width() - 10, 10))

        pygame.display.update()

try:
    while True:
        main()
except Exception as e:
    print("An error occurred:", e)
    pygame.quit()
    quit()
